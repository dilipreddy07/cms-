import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Badge } from "@/app/components/ui/badge";
import { Progress } from "@/app/components/ui/progress";
import {
  Eye,
  Shield,
  ClipboardCheck,
  FileText,
  ListChecks,
  AlertCircle,
  AlertTriangle,
  BarChart3,
  TrendingUp,
  CheckCircle,
  Clock,
  Layers,
  Play,
  Target
} from "lucide-react";
import { AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { cn } from "@/lib/utils";
import { ProjectDataProvider, useProjectData } from "@/app/context/ProjectDataContext";
import { SelectedStandardsView } from "@/app/components/SelectedStandardsView";
import { SelectedStandardDetailsView } from "@/app/components/process-head/definition-phase/SelectedStandardDetailsView";
import { RiskProcedureView } from "@/app/components/process-head/definition-phase/RiskProcedureView";
import { DefinitionStatusView } from "@/app/components/process-head/definition-phase/DefinitionStatusView";
import { ProjectProgressView } from "@/app/components/implementation-phase/ProjectProgressView";
import { TaskManagementView } from "@/app/components/implementation-phase/TaskManagementView";
import { IssueManagementView } from "@/app/components/implementation-phase/IssueManagementView";
import { RiskMonitoringView } from "@/app/components/implementation-phase/RiskMonitoringView";
import { ProjectReportsView } from "@/app/components/implementation-phase/ProjectReportsView";
import { ValidationDashboardView } from "@/app/components/validation-phase/ValidationDashboardView";
import { ProjectReviewView } from "@/app/components/validation-phase/ProjectReviewView";
import { QualityVerificationView } from "@/app/components/validation-phase/QualityVerificationView";
import { ProjectMetricsView } from "@/app/components/validation-phase/ProjectMetricsView";
import { FinalReportView } from "@/app/components/validation-phase/FinalReportView";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/app/components/ui/dropdown-menu";

type ProcessPage = 
  | "dashboard" 
  // Definition Phase
  | "standard"
  | "risk-procedure"
  | "definition-status"
  // Implementation Phase
  | "procedure-implementation" 
  | "task-management" 
  | "issue-management" 
  | "risk-management" 
  | "progress-tracking"
  // Validation Phase
  | "quality-verification" 
  | "project-metrics" 
  | "objective-achievement-progress";

type PhaseType = "definition" | "implementation" | "validation";

interface ProcessHeadDashboardProps {
  department: string;
  phase: PhaseType;
  systemConfig?: {
    industry: string;
    department: string;
    complianceStandards: string[];
    clientName: string;
    location: string;
    address: string;
    organizationSize: string;
  };
  onLogout?: () => void;
}

function ProcessHeadDashboardContent({ department, phase, systemConfig, onLogout }: ProcessHeadDashboardProps) {
  const [currentPage, setCurrentPage] = useState<ProcessPage>("dashboard");
  const [selectedStandard, setSelectedStandard] = useState<{ code: string; name: string } | null>(null);
  const projectData = useProjectData();

  // Menu items organized by phase
  const definitionMenuItems = [
    { id: "standard" as ProcessPage, label: "Standard", icon: Shield },
    { id: "risk-procedure" as ProcessPage, label: "Risk Procedure", icon: AlertCircle },
    { id: "definition-status" as ProcessPage, label: "Definition Status", icon: BarChart3 }
  ];

  const implementationMenuItems = [
    { id: "procedure-implementation" as ProcessPage, label: "Procedure Implementation", icon: TrendingUp },
    { id: "task-management" as ProcessPage, label: "Task Management", icon: ListChecks },
    { id: "issue-management" as ProcessPage, label: "Issue Management", icon: AlertTriangle },
    { id: "risk-management" as ProcessPage, label: "Risk Management", icon: AlertCircle },
    { id: "progress-tracking" as ProcessPage, label: "Progress Tracking", icon: FileText }
  ];

  const validationMenuItems = [
    { id: "quality-verification" as ProcessPage, label: "Quality Verification", icon: CheckCircle },
    { id: "project-metrics" as ProcessPage, label: "Project Metrics", icon: BarChart3 },
    { id: "objective-achievement-progress" as ProcessPage, label: "Objective Achievement Progress", icon: FileText }
  ];

  // Get current menu items based on selected phase
  const getCurrentMenuItems = () => {
    switch (phase) {
      case "definition": return definitionMenuItems;
      case "implementation": return implementationMenuItems;
      case "validation": return validationMenuItems;
      default: return definitionMenuItems;
    }
  };

  const renderContent = () => {
    // Show standard details if a standard is selected
    if (selectedStandard) {
      return <SelectedStandardDetailsView 
        standard={selectedStandard} 
        onBack={() => setSelectedStandard(null)}
      />;
    }

    if (currentPage === "dashboard") {
      return <UnifiedDashboard onNavigate={setCurrentPage} currentPhase={phase} />;
    }
    
    // Definition Phase Pages
    if (currentPage === "standard") {
      return <SelectedStandardsView 
        complianceStandards={systemConfig?.complianceStandards || []} 
        industry={systemConfig?.industry || department} 
        onSelectStandard={(standard) => setSelectedStandard(standard)}
      />;
    }
    if (currentPage === "risk-procedure") return <RiskProcedureView />;
    if (currentPage === "definition-status") return <DefinitionStatusView />;
    
    // Implementation Phase Pages
    if (currentPage === "procedure-implementation") return <ProjectProgressView />;
    if (currentPage === "task-management") return <TaskManagementView />;
    if (currentPage === "issue-management") return <IssueManagementView />;
    if (currentPage === "risk-management") return <RiskMonitoringView />;
    if (currentPage === "progress-tracking") return <ProjectReportsView />;
    
    // Validation Phase Pages
    if (currentPage === "quality-verification") return <QualityVerificationView />;
    if (currentPage === "project-metrics") return <ProjectMetricsView />;
    if (currentPage === "objective-achievement-progress") return <FinalReportView />;
    
    return null;
  };

  const handleLogout = () => {
    if (onLogout) {
      onLogout();
    } else {
      window.location.href = '/';
    }
  };

  return (
    <div className="min-h-screen bg-white p-6">
      <div className="flex gap-6">
        {/* Sidebar */}
        <div className="w-64 flex-shrink-0">
          <Card className="sticky top-6 border-0 shadow-lg bg-gradient-to-br from-purple-50 to-pink-50">
            <CardHeader className="pb-3 border-b border-purple-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg shadow-md">
                  {phase === "definition" && <Layers className="h-5 w-5 text-white" />}
                  {phase === "implementation" && <Play className="h-5 w-5 text-white" />}
                  {phase === "validation" && <Target className="h-5 w-5 text-white" />}
                </div>
                <div>
                  <CardTitle className="text-sm bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent font-bold">
                    {phase === "definition" && "Definition Phase"}
                    {phase === "implementation" && "Implementation Phase"}
                    {phase === "validation" && "Validation Phase"}
                  </CardTitle>
                  <p className="text-xs text-purple-600">Phase Menu</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-1 pb-6">
              <button
                onClick={() => setCurrentPage("dashboard")}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-left",
                  currentPage === "dashboard"
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white font-medium shadow-md"
                    : "hover:bg-white/60 text-gray-700 hover:text-gray-900"
                )}
              >
                <div className={cn(
                  "p-1.5 rounded-md",
                  currentPage === "dashboard" ? "bg-white/20 text-white" : "bg-white text-gray-600"
                )}>
                  <Eye className="h-4 w-4" />
                </div>
                <span className="text-sm">Dashboard</span>
              </button>
              
              {getCurrentMenuItems().map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentPage(item.id)}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-left",
                      isActive
                        ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white font-medium shadow-md"
                        : "hover:bg-white/60 text-gray-700 hover:text-gray-900"
                    )}
                  >
                    <div className={cn(
                      "p-1.5 rounded-md",
                      isActive ? "bg-white/20 text-white" : "bg-white text-gray-600"
                    )}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <span className="text-sm">{item.label}</span>
                  </button>
                );
              })}
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="flex-1 min-w-0">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

// Unified Dashboard showing overview from all phases
function UnifiedDashboard({ onNavigate, currentPhase }: { onNavigate: (page: ProcessPage) => void; currentPhase: PhaseType }) {
  const projectData = useProjectData();

  return (
    <div className="space-y-6">
      {/* Phase Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-0 shadow-lg bg-gradient-to-br from-cyan-400 to-blue-500 text-white">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-cyan-50">Total Requirements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{projectData.complianceRequirements.length}</div>
              <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                <ClipboardCheck className="h-6 w-6" />
              </div>
            </div>
            <Progress value={75} className="h-1 mt-2 bg-white/30" />
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-400 to-indigo-500 text-white">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-purple-50">Active Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{projectData.tasks.length}</div>
              <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                <ListChecks className="h-6 w-6" />
              </div>
            </div>
            <Progress value={60} className="h-1 mt-2 bg-white/30" />
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-amber-400 to-orange-500 text-white">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-amber-50">Open Issues</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{projectData.issues.filter(i => i.status === "Open").length}</div>
              <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                <AlertTriangle className="h-6 w-6" />
              </div>
            </div>
            <Progress value={30} className="h-1 mt-2 bg-white/30" />
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-emerald-400 to-teal-500 text-white">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-emerald-50">Completion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">87%</div>
              <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                <TrendingUp className="h-6 w-6" />
              </div>
            </div>
            <Progress value={87} className="h-1 mt-2 bg-white/30" />
          </CardContent>
        </Card>
      </div>

      {/* Phase-specific Quick Actions */}
      <Card>
        <CardHeader className="bg-gradient-to-r from-gray-50 to-slate-50 border-b">
          <CardTitle className="text-gray-900">
            {currentPhase === "definition" && "Definition Phase - Quick Actions"}
            {currentPhase === "implementation" && "Implementation Phase - Quick Actions"}
            {currentPhase === "validation" && "Validation Phase - Quick Actions"}
          </CardTitle>
          <CardDescription>Access key features and manage your compliance workflow</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {currentPhase === "definition" && (
              <>
                <Button 
                  onClick={() => onNavigate("standard")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-blue-500 to-cyan-500"
                >
                  <Shield className="h-6 w-6" />
                  <span>Standard</span>
                  <Badge className="bg-white/20 text-white border-0">Standards</Badge>
                </Button>
                <Button 
                  onClick={() => onNavigate("risk-procedure")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-red-500 to-orange-500"
                >
                  <AlertCircle className="h-6 w-6" />
                  <span>Risk Procedure</span>
                  <Badge className="bg-white/20 text-white border-0">{projectData.risks.length}</Badge>
                </Button>
                <Button 
                  onClick={() => onNavigate("definition-status")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-green-500 to-emerald-500"
                >
                  <BarChart3 className="h-6 w-6" />
                  <span>Definition Status</span>
                  <Badge className="bg-white/20 text-white border-0">Progress</Badge>
                </Button>
              </>
            )}
            
            {currentPhase === "implementation" && (
              <>
                <Button 
                  onClick={() => onNavigate("task-management")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-green-500 to-emerald-500"
                >
                  <ListChecks className="h-6 w-6" />
                  <span>Task Management</span>
                  <Badge className="bg-white/20 text-white border-0">{projectData.tasks.length}</Badge>
                </Button>
                <Button 
                  onClick={() => onNavigate("issue-management")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-amber-500 to-orange-500"
                >
                  <AlertTriangle className="h-6 w-6" />
                  <span>Issue Management</span>
                  <Badge className="bg-white/20 text-white border-0">{projectData.issues.length}</Badge>
                </Button>
                <Button 
                  onClick={() => onNavigate("procedure-implementation")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-blue-500 to-cyan-500"
                >
                  <TrendingUp className="h-6 w-6" />
                  <span>Procedure Implementation</span>
                  <Badge className="bg-white/20 text-white border-0">Live</Badge>
                </Button>
              </>
            )}
            
            {currentPhase === "validation" && (
              <>
                <Button 
                  onClick={() => onNavigate("quality-verification")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-green-500 to-emerald-500"
                >
                  <CheckCircle className="h-6 w-6" />
                  <span>Quality Verification</span>
                  <Badge className="bg-white/20 text-white border-0">{projectData.qualityVerifications.length}</Badge>
                </Button>
                <Button 
                  onClick={() => onNavigate("project-metrics")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-blue-500 to-cyan-500"
                >
                  <BarChart3 className="h-6 w-6" />
                  <span>Project Metrics</span>
                  <Badge className="bg-white/20 text-white border-0">Metrics</Badge>
                </Button>
                <Button 
                  onClick={() => onNavigate("objective-achievement-progress")}
                  className="h-auto py-4 flex-col gap-2 bg-gradient-to-br from-orange-500 to-amber-500"
                >
                  <FileText className="h-6 w-6" />
                  <span>Objective Achievement Progress</span>
                  <Badge className="bg-white/20 text-white border-0">{projectData.finalReports.length}</Badge>
                </Button>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="border-b bg-gray-50">
            <CardTitle className="text-gray-900">Project Progress Trend</CardTitle>
            <CardDescription>Completion metrics over time</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={[
                { id: 'jan', month: 'Jan', completion: 15 },
                { id: 'feb', month: 'Feb', completion: 32 },
                { id: 'mar', month: 'Mar', completion: 48 },
                { id: 'apr', month: 'Apr', completion: 65 },
                { id: 'may', month: 'May', completion: 78 },
                { id: 'jun', month: 'Jun', completion: 87 }
              ]}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip />
                <Area type="monotone" dataKey="completion" stroke="#8b5cf6" fill="#c4b5fd" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="border-b bg-gray-50">
            <CardTitle className="text-gray-900">Phase Distribution</CardTitle>
            <CardDescription>Work items by phase</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={[
                    { id: 'definition', name: 'Definition', value: projectData.complianceRequirements.length + projectData.standardDocuments.length, color: '#3b82f6' },
                    { id: 'implementation', name: 'Implementation', value: projectData.tasks.length + projectData.issues.length, color: '#10b981' },
                    { id: 'validation', name: 'Validation', value: projectData.projectReviews.length + projectData.qualityVerifications.length, color: '#f59e0b' }
                  ]}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {[
                    { id: 'definition', fill: '#3b82f6' },
                    { id: 'implementation', fill: '#10b981' },
                    { id: 'validation', fill: '#f59e0b' }
                  ].map((entry) => (
                    <Cell key={`phase-cell-${entry.id}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader className="bg-gray-50 border-b">
          <CardTitle className="text-gray-900">Recent Activity Across All Phases</CardTitle>
          <CardDescription>Latest updates from definition, implementation, and validation</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-3">
            {[
              { action: "New compliance requirement added", phase: "Definition", time: "5 minutes ago", color: "bg-blue-500", icon: ClipboardCheck },
              { action: "Task completed: Asset Inventory", phase: "Implementation", time: "12 minutes ago", color: "bg-green-500", icon: CheckCircle },
              { action: "Quality verification passed", phase: "Validation", time: "25 minutes ago", color: "bg-orange-500", icon: Shield },
              { action: "Risk assessment updated", phase: "Definition", time: "1 hour ago", color: "bg-red-500", icon: AlertCircle },
              { action: "Final report approved", phase: "Validation", time: "2 hours ago", color: "bg-purple-500", icon: FileText }
            ].map((activity, idx) => {
              const Icon = activity.icon;
              return (
                <div key={idx} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-all">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 ${activity.color} rounded-lg`}>
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-sm text-gray-900">{activity.action}</p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        <Badge variant="outline" className="mr-2">{activity.phase}</Badge>
                        {activity.time}
                      </p>
                    </div>
                  </div>
                  <Clock className="h-4 w-4 text-gray-400" />
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Validation Overview Section - Only shown when in Validation Phase */}
      {currentPhase === "validation" && (
        <Card className="border-2 border-purple-200 shadow-xl">
          <CardHeader className="bg-gradient-to-r from-purple-500 via-indigo-500 to-blue-500 text-white border-b">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                <Shield className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className="text-white text-xl">Validation Overview</CardTitle>
                <CardDescription className="text-white/90">Monitor validation progress and approval status</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            {/* Validation Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card className="border-0 shadow-md bg-gradient-to-br from-green-500 to-emerald-500 text-white">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-3xl font-bold">47</div>
                      <p className="text-sm text-white/80 mt-1">Total Validated</p>
                    </div>
                    <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                      <CheckCircle className="h-8 w-8" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-md bg-gradient-to-br from-yellow-500 to-amber-500 text-white">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-3xl font-bold">12</div>
                      <p className="text-sm text-white/80 mt-1">Pending Validations</p>
                    </div>
                    <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                      <Clock className="h-8 w-8" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-md bg-gradient-to-br from-blue-500 to-cyan-500 text-white">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-3xl font-bold">42</div>
                      <p className="text-sm text-white/80 mt-1">Approved</p>
                    </div>
                    <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                      <CheckCircle className="h-8 w-8" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-md bg-gradient-to-br from-red-500 to-orange-500 text-white">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-3xl font-bold">5</div>
                      <p className="text-sm text-white/80 mt-1">Rejected</p>
                    </div>
                    <div className="p-3 bg-white/20 backdrop-blur rounded-lg">
                      <AlertCircle className="h-8 w-8" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Validation Activities */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg text-gray-900">Recent Validation Activities</h3>
              <div className="space-y-3">
                {[
                  { procedure: "ISO 27001 Security Controls", status: "Approved", date: "2026-03-17", reviewer: "Quality Manager", color: "bg-green-500" },
                  { procedure: "GDPR Data Protection Measures", status: "Approved", date: "2026-03-16", reviewer: "Compliance Officer", color: "bg-green-500" },
                  { procedure: "Risk Management Framework", status: "Pending", date: "2026-03-15", reviewer: "Process Head", color: "bg-yellow-500" },
                  { procedure: "Incident Response Plan", status: "Approved", date: "2026-03-14", reviewer: "Security Lead", color: "bg-green-500" },
                  { procedure: "Access Control Policy", status: "Rejected", date: "2026-03-13", reviewer: "IT Manager", color: "bg-red-500" },
                  { procedure: "Business Continuity Plan", status: "Pending", date: "2026-03-12", reviewer: "Operations Head", color: "bg-yellow-500" }
                ].map((activity, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-all">
                    <div className="flex items-center gap-4 flex-1">
                      <div className={`p-2 ${activity.color} rounded-lg`}>
                        {activity.status === "Approved" && <CheckCircle className="h-5 w-5 text-white" />}
                        {activity.status === "Pending" && <Clock className="h-5 w-5 text-white" />}
                        {activity.status === "Rejected" && <AlertCircle className="h-5 w-5 text-white" />}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm text-gray-900">{activity.procedure}</p>
                        <p className="text-xs text-gray-500 mt-0.5">
                          Reviewed by {activity.reviewer} • {activity.date}
                        </p>
                      </div>
                    </div>
                    <Badge className={
                      activity.status === "Approved" ? "bg-green-500 text-white" :
                      activity.status === "Pending" ? "bg-yellow-500 text-white" :
                      "bg-red-500 text-white"
                    }>
                      {activity.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export function ProcessHeadDashboard(props: ProcessHeadDashboardProps) {
  return (
    <ProjectDataProvider>
      <ProcessHeadDashboardContent {...props} />
    </ProjectDataProvider>
  );
}